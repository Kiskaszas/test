const api = {
    list: '/api/nodes',
    get: id => `/api/node/${id}`,
    save: '/api/node',
    delete: id => `/api/node/${id}`,
    search: q => `/api/search?q=${encodeURIComponent(q)}`,
    move: '/api/node/move'
};

let nodes = [];
let selectedId = null;
let debounceTimer = null;

document.addEventListener('DOMContentLoaded', () => {
    loadTree();
    setupButtons();
    document.getElementById('searchInput').addEventListener('input', onSearchInput);
});

function loadTree() {
    fetch(api.list).then(r => r.json()).then(data => {
        nodes = data;
        renderTree();
        populateParentSelect();
    });
}

function renderTree(filter = '') {
    const root = document.getElementById('treeRoot');
    root.innerHTML = '';
    // build map by parent
    const map = {};
    nodes.forEach(n => {
        const p = n.parentId || 'root';
        if (!map[p]) map[p] = [];
        map[p].push(n);
    });

    const buildList = (parentId, ul) => {
        const children = map[parentId] || [];
        children.sort((a,b)=>a.name.localeCompare(b.name));
        children.forEach(n => {
            const li = document.createElement('li');
            const div = document.createElement('div');
            div.className = 'tree-node';
            div.draggable = true;
            div.dataset.id = n.id;
            div.textContent = n.name;
            // highlight filter
            if (filter) {
                const matches = n.name.toLowerCase().includes(filter) || n.content.toLowerCase().includes(filter);
                if (!matches) div.classList.add('dimmed');
            }
            div.addEventListener('click', () => selectNode(n.id));
            div.addEventListener('dragstart', onDragStart);
            div.addEventListener('dragover', e => e.preventDefault());
            div.addEventListener('drop', onDrop);
            if (n.id === selectedId) div.classList.add('selected');
            li.appendChild(div);

            // children (only one level allowed)
            const childUl = document.createElement('ul');
            childUl.className = 'list-unstyled ms-3';
            buildList(n.id, childUl);
            li.appendChild(childUl);
            ul.appendChild(li);
        });
    };

    buildList('root', root);
}

function selectNode(id) {
    selectedId = id;
    const node = nodes.find(n => n.id === id);
    document.getElementById('nodeTitle').textContent = node ? node.name : 'Select a node';
    document.getElementById('nodeContent').value = node ? node.content : '';
    document.getElementById('btnEdit').disabled = !node;
    document.getElementById('btnDelete').disabled = !node;
    renderTree(document.getElementById('searchInput').value.trim().toLowerCase());
}

function setupButtons() {
    const nodeModal = new bootstrap.Modal(document.getElementById('nodeModal'));
    document.getElementById('btnNew').addEventListener('click', () => {
        document.getElementById('nodeModalTitle').textContent = 'New Node';
        document.getElementById('nodeId').value = '';
        document.getElementById('nodeName').value = '';
        document.getElementById('nodeContentInput').value = '';
        populateParentSelect();
        nodeModal.show();
    });

    document.getElementById('btnEdit').addEventListener('click', () => {
        if (!selectedId) return;
        const node = nodes.find(n => n.id === selectedId);
        document.getElementById('nodeModalTitle').textContent = 'Edit Node';
        document.getElementById('nodeId').value = node.id;
        document.getElementById('nodeName').value = node.name;
        document.getElementById('nodeContentInput').value = node.content;
        populateParentSelect(node.parentId);
        nodeModal.show();
    });

    document.getElementById('nodeForm').addEventListener('submit', (e) => {
        e.preventDefault();
        const id = document.getElementById('nodeId').value;
        const name = document.getElementById('nodeName').value.trim();
        const content = document.getElementById('nodeContentInput').value.trim();
        const parentId = document.getElementById('nodeParent').value || null;
        const payload = { name, content, parentId };
        if (id) payload.id = id;
        fetch(api.save, {
            method: 'POST',
            headers: {'Content-Type':'application/json'},
            body: JSON.stringify(payload)
        }).then(r => r.json()).then(saved => {
            loadTree();
            bootstrap.Modal.getInstance(document.getElementById('nodeModal')).hide();
            selectNode(saved.id);
        }).catch(err => alert('Error saving node: ' + err));
    });

    // delete
    const confirmModal = new bootstrap.Modal(document.getElementById('confirmDeleteModal'));
    document.getElementById('btnDelete').addEventListener('click', () => {
        if (!selectedId) return;
        const toDelete = collectDescendants(selectedId);
        document.getElementById('deleteInfo').textContent = `This will delete ${toDelete.length} node(s): ${toDelete.join(', ')}`;
        confirmModal.show();
    });
    document.getElementById('confirmDeleteBtn').addEventListener('click', () => {
        fetch(api.delete(selectedId), { method: 'DELETE' }).then(() => {
            confirmModal.hide();
            selectedId = null;
            loadTree();
            document.getElementById('nodeTitle').textContent = 'Select a node';
            document.getElementById('nodeContent').value = '';
        });
    });
}

function populateParentSelect(selected = null) {
    const sel = document.getElementById('nodeParent');
    sel.innerHTML = '<option value="">(root)</option>';
    nodes.filter(n => n.parentId == null).forEach(n => {
        const opt = document.createElement('option');
        opt.value = n.id;
        opt.textContent = n.name;
        if (n.id === selected) opt.selected = true;
        sel.appendChild(opt);
    });
}

function collectDescendants(id) {
    const map = {};
    nodes.forEach(n => {
        const p = n.parentId || 'root';
        if (!map[p]) map[p] = [];
        map[p].push(n);
    });
    const acc = [];
    function rec(curr) {
        acc.push(curr);
        const children = map[curr] || [];
        children.forEach(c => rec(c.id));
    }
    rec(id);
    return acc;
}

let dragNodeId = null;
function onDragStart(e) {
    dragNodeId = e.target.dataset.id;
    e.dataTransfer.setData('text/plain', dragNodeId);
}

function onDrop(e) {
    e.preventDefault();
    const targetId = e.currentTarget.dataset.id;
    if (!dragNodeId || dragNodeId === targetId) return;

    fetch(api.move, {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({ nodeId: dragNodeId, newParentId: targetId })
    }).then(r => {
        if (!r.ok) return r.text().then(t => { throw new Error(t) });
        return r.json();
    }).then(() => {
        loadTree();
    }).catch(err => alert('Move failed: ' + err));
}

function onSearchInput(e) {
    const q = e.target.value.trim().toLowerCase();
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => {
        renderTree(q);
    }, 300);
}