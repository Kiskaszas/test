package org.treeapp.db.model;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.validation.constraints.NotBlank;
import java.util.ArrayList;
import java.util.List;

@Document(collection = "tree_nodes")
@Data
public class TreeNode {
    @Id
    private String id;

    @NotBlank
    private String name;

    @NotBlank
    private String content;

    private String parentId;

    private List<String> children = new ArrayList<>();

    public TreeNode() {}

    public TreeNode(String name, String content, String parentId) {
        this.name = name;
        this.content = content;
        this.parentId = parentId;
    }
}