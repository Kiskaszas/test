package org.treeapp.db.repository;

import org.treeapp.db.model.TreeNode;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface TreeNodeRepository extends MongoRepository<TreeNode, String> {
    List<TreeNode> findByParentId(String parentId);
    List<TreeNode> findByNameContainingIgnoreCaseOrContentContainingIgnoreCase(String name, String content);
}