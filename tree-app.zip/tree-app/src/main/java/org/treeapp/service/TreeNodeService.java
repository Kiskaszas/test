package org.treeapp.service;

import org.treeapp.db.model.TreeNode;
import org.treeapp.db.repository.TreeNodeRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
public class TreeNodeService {
    private final TreeNodeRepository repo;

    public TreeNodeService(TreeNodeRepository repo) {
        this.repo = repo;
    }

    public TreeNode createOrUpdate(TreeNode node) {

        if (node.getParentId() != null) {
            TreeNode parent = repo.findById(node.getParentId())
                    .orElseThrow(() -> new NoSuchElementException("Parent not found"));
            if (parent.getParentId() != null) {
                throw new IllegalArgumentException("Multi-level trees are not allowed");
            }
        }

        TreeNode saved = repo.save(node);

        if (node.getParentId() != null) {
            repo.findById(node.getParentId()).ifPresent(p -> {
                if (!p.getChildren().contains(saved.getId())) {
                    p.getChildren().add(saved.getId());
                    repo.save(p);
                }
            });
        }

        return saved;
    }

    @Transactional
    public void deleteRecursively(String id) {
        List<String> toDelete = new ArrayList<>();
        collectDescendants(id, toDelete);

        repo.findById(id).ifPresent(node -> {
            if (node.getParentId() != null) {
                repo.findById(node.getParentId()).ifPresent(parent -> {
                    parent.getChildren().remove(id);
                    repo.save(parent);
                });
            }
        });

        repo.deleteAllById(toDelete);
    }

    private void collectDescendants(String id, List<String> acc) {
        acc.add(id);
        List<TreeNode> children = repo.findByParentId(id);
        for (TreeNode c : children) {
            collectDescendants(c.getId(), acc);
        }
    }

    public List<TreeNode> listAll() {
        return repo.findAll();
    }

    public Optional<TreeNode> findById(String id) {
        return repo.findById(id);
    }

    public List<TreeNode> search(String q) {
        return repo.findByNameContainingIgnoreCaseOrContentContainingIgnoreCase(q, q);
    }

    @Transactional
    public TreeNode moveNode(String nodeId, String newParentId) {

        TreeNode node = repo.findById(nodeId).orElseThrow(() -> new NoSuchElementException("Node not found"));

        if (newParentId != null) {
            TreeNode newParent = repo.findById(newParentId).orElseThrow(() -> new NoSuchElementException("New parent not found"));
            if (newParent.getParentId() != null) {
                throw new IllegalArgumentException("Cannot move under a non-root node (would create multi-level)");
            }

            if (node.getParentId() != null) {
                repo.findById(node.getParentId()).ifPresent(oldParent -> {
                    oldParent.getChildren().remove(node.getId());
                    repo.save(oldParent);
                });
            }

            node.setParentId(newParentId);
            repo.save(node);

            if (!newParent.getChildren().contains(node.getId())) {
                newParent.getChildren().add(node.getId());
                repo.save(newParent);
            }
        } else {

            if (node.getParentId() != null) {
                repo.findById(node.getParentId()).ifPresent(oldParent -> {
                    oldParent.getChildren().remove(node.getId());
                    repo.save(oldParent);
                });
            }

            node.setParentId(null);
            repo.save(node);
        }
        return node;
    }
}