package org.treeapp.dto;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MoveRequest {
    private String nodeId;
    private String newParentId;

    public MoveRequest() {}

    @JsonCreator
    public MoveRequest(
            @JsonProperty("nodeId") String nodeId,
            @JsonProperty("newParentId") String newParentId
    ) {
        this.nodeId = nodeId;
        this.newParentId = newParentId;
    }
}