package org.treeapp.controller;

import org.treeapp.dto.MoveRequest;
import org.treeapp.db.model.TreeNode;
import org.treeapp.service.TreeNodeService;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@Controller
@Validated
public class TreeNodeController {
    private final TreeNodeService service;

    public TreeNodeController(TreeNodeService service) {
        this.service = service;
    }

    @GetMapping("/")
    public String index(Model model) {
        model.addAttribute("nodes", service.listAll());
        return "index";
    }

    @PostMapping("/api/node")
    @ResponseBody
    public ResponseEntity<TreeNode> createOrUpdate(@Valid @RequestBody TreeNode node) {
        TreeNode saved = service.createOrUpdate(node);
        return ResponseEntity.ok(saved);
    }

    @DeleteMapping("/api/node/{id}")
    @ResponseBody
    public ResponseEntity<Void> delete(@PathVariable("id") String id) {
        service.deleteRecursively(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/api/nodes")
    @ResponseBody
    public ResponseEntity<List<TreeNode>> listAll() {
        return ResponseEntity.ok(service.listAll());
    }

    @GetMapping("/api/node/{id}")
    @ResponseBody
    public ResponseEntity<TreeNode> getById(@PathVariable("id") String id) {
        return service.findById(id).map(
                ResponseEntity::ok).orElseGet(
                        () -> ResponseEntity.notFound().build()
        );
    }

    @GetMapping("/api/search")
    @ResponseBody
    public ResponseEntity<List<TreeNode>> search(@RequestParam String element) {
        return ResponseEntity.ok(service.search(element));
    }

    @PostMapping("/api/node/move")
    @ResponseBody
    public ResponseEntity<TreeNode> move(@Valid @RequestBody MoveRequest request) {
        TreeNode moved = service.moveNode(request.getNodeId(), request.getNewParentId());
        return ResponseEntity.ok(moved);
    }
}