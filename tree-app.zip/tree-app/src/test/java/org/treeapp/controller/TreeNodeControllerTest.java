package org.treeapp.controller;

import org.treeapp.db.model.TreeNode;
import org.treeapp.service.TreeNodeService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(TreeNodeController.class)
public class TreeNodeControllerTest {
    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private TreeNodeService service;

    @Test
    public void createNode_returnsOk() throws Exception {
        TreeNode node = new TreeNode("Name", "Content", null);
        node.setId("1");
        when(service.createOrUpdate(any())).thenReturn(node);

        mockMvc.perform(post("/api/node")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"name\":\"Name\",\"content\":\"Content\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value("1"))
                .andExpect(jsonPath("$.name").value("Name"));
    }

    @Test
    public void deleteNode_returnsNoContent() throws Exception {
        doNothing().when(service).deleteRecursively("1");
        mockMvc.perform(delete("/api/node/1"))
                .andExpect(status().isNoContent());
    }
}